// AI Connect - Main JavaScript
// Interactive Features & AI Simulation

class AIConnect {
    constructor() {
        this.posts = [];
        this.users = [];
        this.currentUser = null;
        this.aiInsights = this.generateAIInsights();
        this.searchIndex = [];
        this.init();
    }

    init() {
        this.loadSampleData();
        this.setupEventListeners();
        this.initializeRealtimeFeatures();
        this.startAIAnalysis();
        this.updateUserStats();
    }

    // Load sample data for demonstration
    loadSampleData() {
        this.posts = [
            {
                id: 1,
                author: "Sarah Chen",
                handle: "@sarahchen_ai",
                avatar: "https://images.unsplash.com/photo-1494790108755-2616b332c8c2?w=100&h=100&fit=crop&crop=face",
                content: "Just discovered an incredible breakthrough in natural language processing! The latest advances in transformer architectures are making AI more conversational and contextually aware than ever before. This is going to revolutionize how we interact with technology.",
                timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
                likes: 42,
                comments: 18,
                shares: 12,
                aiTags: [
                    { label: "AI: Optimistic Tone", type: "sentiment" },
                    { label: "AI: High Engagement Potential", type: "engagement" }
                ]
            },
            {
                id: 2,
                author: "Marcus Rodriguez",
                handle: "@marcus_tech",
                avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face",
                content: "Attended an amazing AI ethics workshop today. The discussion about responsible AI development and the importance of diversity in tech really opened my eyes. We need more voices in these conversations!",
                timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000),
                likes: 67,
                comments: 23,
                shares: 8,
                aiTags: [
                    { label: "AI: Positive Sentiment", type: "sentiment" },
                    { label: "AI: Educational Content", type: "content" }
                ]
            },
            {
                id: 3,
                author: "Dr. Emily Watson",
                handle: "@drwatson_ai",
                avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face",
                content: "Exciting news! Our research team just published a paper on AI-assisted content creation. The findings show that AI can enhance human creativity rather than replace it. This could transform how we think about collaboration between humans and AI.",
                timestamp: new Date(Date.now() - 6 * 60 * 60 * 1000),
                likes: 134,
                comments: 45,
                shares: 29,
                aiTags: [
                    { label: "AI: High Credibility", type: "credibility" },
                    { label: "AI: Research Content", type: "content" }
                ]
            }
        ];

        this.users = [
            {
                name: "Alex Johnson",
                title: "AI Researcher & Social Innovator",
                avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face",
                connections: 1200,
                engagement: 847
            }
        ];

        this.currentUser = this.users[0];
    }

    // Setup all event listeners
    setupEventListeners() {
        // Post interactions
        this.setupPostInteractions();
        
        // Composer functionality
        this.setupComposer();
        
        // Search functionality
        this.setupSearch();
        
        // Navigation
        this.setupNavigation();
        
        // AI suggestions
        this.setupAISuggestions();
        
        // Connection requests
        this.setupConnectionRequests();
    }

    // Post interaction handlers
    setupPostInteractions() {
        const likeButtons = document.querySelectorAll('[data-action="like"]');
        const commentButtons = document.querySelectorAll('[data-action="comment"]');
        const shareButtons = document.querySelectorAll('[data-action="share"]');

        likeButtons.forEach((button, index) => {
            button.addEventListener('click', () => this.handleLike(index, button));
        });

        commentButtons.forEach((button, index) => {
            button.addEventListener('click', () => this.handleComment(index, button));
        });

        shareButtons.forEach((button, index) => {
            button.addEventListener('click', () => this.handleShare(index, button));
        });
    }

    handleLike(postIndex, button) {
        const post = this.posts[postIndex];
        const countSpan = button.querySelector('span');
        
        // Simulate AI-enhanced like
        const isLiked = button.classList.contains('liked');
        
        if (isLiked) {
            post.likes--;
            button.classList.remove('liked');
            button.style.color = 'var(--neutral-600)';
        } else {
            post.likes++;
            button.classList.add('liked');
            button.style.color = 'var(--error)';
            
            // Trigger AI sentiment analysis
            this.analyzeEngagement(post, 'like');
        }
        
        countSpan.textContent = post.likes;
        
        // Add visual feedback
        button.style.transform = 'scale(1.1)';
        setTimeout(() => {
            button.style.transform = 'scale(1)';
        }, 150);
    }

    handleComment(postIndex, button) {
        const post = this.posts[postIndex];
        
        // Simulate opening comment interface
        this.showCommentInterface(post, postIndex);
        
        // Update comment count
        const countSpan = button.querySelector('span');
        post.comments++;
        countSpan.textContent = post.comments;
        
        // AI insight
        this.analyzeEngagement(post, 'comment');
    }

    handleShare(postIndex, button) {
        const post = this.posts[postIndex];
        const countSpan = button.querySelector('span');
        
        post.shares++;
        countSpan.textContent = post.shares;
        
        // Show share modal
        this.showShareModal(post);
        
        // AI analysis
        this.analyzeEngagement(post, 'share');
    }

    // Comment interface simulation
    showCommentInterface(post, postIndex) {
        // This would typically open a comment modal
        // For demo, we'll just show a notification
        this.showNotification(`Opening comments for ${post.author}'s post`, 'info');
        
        // Simulate some AI-powered comment suggestions
        setTimeout(() => {
            const suggestions = this.generateCommentSuggestions(post.content);
            this.showCommentSuggestions(suggestions);
        }, 1000);
    }

    // Share modal simulation
    showShareModal(post) {
        this.showNotification(`Share modal would open for post by ${post.author}`, 'success');
    }

    // AI-powered comment suggestions
    generateCommentSuggestions(content) {
        const suggestions = [
            "This is fascinating! Could you elaborate on the technical implementation?",
            "I completely agree. Have you considered the ethical implications?",
            "This could have huge applications in healthcare. What do you think?",
            "Great insights! How do you see this evolving in the next 5 years?",
            "I'm working on something similar. Would love to connect and discuss!"
        ];
        
        // Filter based on content
        return suggestions.filter(suggestion => 
            suggestion.toLowerCase().includes('technical') && content.includes('transformer') ||
            suggestion.toLowerCase().includes('ethical') && content.includes('ethics') ||
            suggestion.toLowerCase().includes('healthcare') ||
            suggestion.toLowerCase().includes('years') ||
            suggestion.toLowerCase().includes('similar')
        ).slice(0, 3);
    }

    // Composer functionality
    setupComposer() {
        const composerInput = document.querySelector('.composer-input');
        const postButton = document.querySelector('.btn-primary');
        
        if (composerInput && postButton) {
            composerInput.addEventListener('input', (e) => {
                this.updateComposerState(e.target.value);
            });
            
            postButton.addEventListener('click', () => {
                this.createNewPost(composerInput.value);
                composerInput.value = '';
                this.updateComposerState('');
            });
        }
    }

    updateComposerState(content) {
        const aiSuggestions = document.querySelector('.ai-suggestions');
        const postButton = document.querySelector('.composer-controls .btn-primary');
        
        if (content.length > 10) {
            // Generate AI suggestions based on content
            const suggestions = this.generateContentSuggestions(content);
            this.updateAISuggestions(suggestions);
            postButton.disabled = false;
            postButton.style.opacity = '1';
        } else {
            postButton.disabled = true;
            postButton.style.opacity = '0.5';
        }
    }

    generateContentSuggestions(content) {
        const words = content.toLowerCase().split(' ');
        const suggestions = [];
        
        if (words.some(word => word.includes('ai') || word.includes('artificial'))) {
            suggestions.push('#ArtificialIntelligence', '#MachineLearning', '#DeepLearning');
        }
        if (words.some(word => word.includes('tech') || word.includes('technology'))) {
            suggestions.push('#Technology', '#Innovation', '#Future');
        }
        if (words.some(word => word.includes('research') || word.includes('study'))) {
            suggestions.push('#Research', '#Science', '#Discovery');
        }
        
        return suggestions.slice(0, 3);
    }

    updateAISuggestions(suggestions) {
        const container = document.querySelector('.ai-suggestions');
        if (!container) return;
        
        container.innerHTML = suggestions.map(suggestion => 
            `<button class="ai-suggestion">${suggestion}</button>`
        ).join('');
        
        // Reattach event listeners
        container.querySelectorAll('.ai-suggestion').forEach(button => {
            button.addEventListener('click', (e) => {
                this.addSuggestionToComposer(e.target.textContent);
            });
        });
    }

    addSuggestionToComposer(suggestion) {
        const composerInput = document.querySelector('.composer-input');
        const currentContent = composerInput.value;
        composerInput.value = currentContent + (currentContent ? ' ' : '') + suggestion;
        this.updateComposerState(composerInput.value);
    }

    createNewPost(content) {
        const newPost = {
            id: this.posts.length + 1,
            author: this.currentUser.name,
            handle: "@alexjohnson",
            avatar: this.currentUser.avatar,
            content: content,
            timestamp: new Date(),
            likes: 0,
            comments: 0,
            shares: 0,
            aiTags: this.analyzePostContent(content)
        };
        
        this.posts.unshift(newPost);
        this.renderNewPost(newPost);
        this.showNotification('Post created successfully! AI is analyzing it now...', 'success');
        
        // Update search index
        this.updateSearchIndex(newPost);
    }

    renderNewPost(post) {
        const feed = document.querySelector('.feed-posts');
        const postElement = this.createPostElement(post);
        feed.insertBefore(postElement, feed.firstChild);
        
        // Reattach event listeners
        this.setupPostInteractions();
    }

    createPostElement(post) {
        const postDiv = document.createElement('div');
        postDiv.className = 'post-card';
        postDiv.innerHTML = `
            <div class="post-header">
                <img src="${post.avatar}" alt="${post.author}" class="post-avatar">
                <div class="post-user-info">
                    <div class="post-user">
                        <span class="user-name">${post.author}</span>
                        <span class="user-handle">${post.handle}</span>
                    </div>
                    <span class="post-time">Just now</span>
                </div>
                <div class="post-actions">
                    <button class="icon-btn">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M6 10H14" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M10 6V14" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </button>
                </div>
            </div>
            <div class="post-content">
                <p class="post-text">${post.content}</p>
                <div class="ai-tags">
                    ${post.aiTags.map(tag => `
                        <div class="ai-tag">
                            <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M6 1L7.5 3.5L10.5 3.5L8 5.5L9 8.5L6 7L3 8.5L4 5.5L1.5 3.5L4.5 3.5L6 1Z" fill="currentColor"/>
                            </svg>
                            <span>${tag.label}</span>
                        </div>
                    `).join('')}
                </div>
            </div>
            <div class="post-interactions">
                <button class="interaction-btn" data-action="like">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M3.172 5.172C3.56795 4.77515 4.115 4.57554 4.687 4.57554C5.25899 4.57554 5.80605 4.77515 6.202 5.172L9.999 8.969L13.797 5.172C14.193 4.77515 14.74 4.57554 15.312 4.57554C15.884 4.57554 16.431 4.77515 16.827 5.172C17.224 5.56895 17.423 6.11601 17.423 6.688C17.423 7.25999 17.224 7.80705 16.827 8.203L9.999 15.031L3.172 8.203C2.77515 7.80705 2.57554 7.25999 2.57554 6.688C2.57554 6.11601 2.77515 5.56895 3.172 5.172Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                    <span>${post.likes}</span>
                </button>
                <button class="interaction-btn" data-action="comment">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M5 8H15" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M5 12H9" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M3 5C3 3.89543 3.89543 3 5 3H15C16.1046 3 17 3.89543 17 5V13C17 14.1046 16.1046 15 15 15H8L3 20V5Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                    <span>${post.comments}</span>
                </button>
                <button class="interaction-btn" data-action="share">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M7 7H17" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M7 13H17" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M7 10L17 4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M7 10L17 16" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                    <span>${post.shares}</span>
                </button>
            </div>
        `;
        return postDiv;
    }

    // Search functionality
    setupSearch() {
        const searchInput = document.querySelector('.search-input');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                this.performSearch(e.target.value);
            });
        }
    }

    performSearch(query) {
        if (query.length < 2) return;
        
        const results = this.searchIndex.filter(item => 
            item.content.toLowerCase().includes(query.toLowerCase()) ||
            item.author.toLowerCase().includes(query.toLowerCase()) ||
            item.tags.some(tag => tag.toLowerCase().includes(query.toLowerCase()))
        );
        
        // This would typically show search results
        console.log('Search results:', results);
    }

    // Navigation setup
    setupNavigation() {
        const navButtons = document.querySelectorAll('.nav-btn');
        navButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                this.handleNavigation(e.currentTarget);
            });
        });
    }

    handleNavigation(button) {
        // Remove active class from all nav buttons
        document.querySelectorAll('.nav-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        
        // Add active class to clicked button
        button.classList.add('active');
        
        // Handle navigation based on button type
        const buttonText = button.querySelector('span').textContent;
        this.showNotification(`Navigating to ${buttonText}`, 'info');
    }

    // AI Suggestions
    setupAISuggestions() {
        const aiSuggestions = document.querySelectorAll('.ai-suggestion');
        aiSuggestions.forEach(suggestion => {
            suggestion.addEventListener('click', (e) => {
                this.handleAISuggestion(e.target.textContent);
            });
        });
    }

    handleAISuggestion(suggestion) {
        this.addSuggestionToComposer(suggestion);
        this.showNotification(`Added AI suggestion: ${suggestion}`, 'success');
    }

    // Connection requests
    setupConnectionRequests() {
        const connectButtons = document.querySelectorAll('.connect-btn');
        connectButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                this.handleConnectionRequest(e.target);
            });
        });
    }

    handleConnectionRequest(button) {
        const userCard = button.closest('.suggestion-item');
        const userName = userCard.querySelector('.suggestion-name').textContent;
        
        button.textContent = 'Requested';
        button.disabled = true;
        button.style.background = 'var(--neutral-300)';
        button.style.color = 'var(--neutral-600)';
        
        this.showNotification(`Connection request sent to ${userName}`, 'success');
        
        // Simulate AI-powered match explanation
        setTimeout(() => {
            this.showConnectionInsight(userName, button);
        }, 1500);
    }

    showConnectionInsight(userName, button) {
        const insights = [
            `AI suggests you and ${userName} share interests in AI research`,
            `Both you and ${userName} have posted about ethical AI recently`,
            `${userName} could be valuable for your AI project collaboration`
        ];
        
        const randomInsight = insights[Math.floor(Math.random() * insights.length)];
        this.showNotification(randomInsight, 'info');
    }

    // AI Analysis Methods
    analyzePostContent(content) {
        const tags = [];
        
        // Simulate sentiment analysis
        const sentiment = this.analyzeSentiment(content);
        if (sentiment > 0.7) {
            tags.push({ label: "AI: Positive Sentiment", type: "sentiment" });
        } else if (sentiment < 0.3) {
            tags.push({ label: "AI: Negative Sentiment", type: "sentiment" });
        }
        
        // Simulate engagement prediction
        const engagementPotential = this.predictEngagement(content);
        if (engagementPotential > 0.6) {
            tags.push({ label: "AI: High Engagement Potential", type: "engagement" });
        }
        
        // Detect technical content
        if (this.containsTechnicalTerms(content)) {
            tags.push({ label: "AI: Technical Content", type: "content" });
        }
        
        // Check for research keywords
        if (this.containsResearchTerms(content)) {
            tags.push({ label: "AI: Research Content", type: "content" });
        }
        
        return tags;
    }

    analyzeSentiment(content) {
        const positiveWords = ['amazing', 'incredible', 'exciting', 'revolutionary', 'fantastic', 'great', 'wonderful'];
        const negativeWords = ['bad', 'terrible', 'awful', 'horrible', 'worst', 'disappointing'];
        
        const words = content.toLowerCase().split(' ');
        let score = 0.5; // neutral baseline
        
        words.forEach(word => {
            if (positiveWords.some(pw => word.includes(pw))) score += 0.1;
            if (negativeWords.some(nw => word.includes(nw))) score -= 0.1;
        });
        
        return Math.max(0, Math.min(1, score));
    }

    predictEngagement(content) {
        let score = 0.3; // baseline
        
        // Questions tend to get more engagement
        if (content.includes('?')) score += 0.2;
        
        // Technical terms attract specific audiences
        if (this.containsTechnicalTerms(content)) score += 0.3;
        
        // Longer posts tend to get more discussion
        if (content.length > 200) score += 0.2;
        
        return Math.min(1, score);
    }

    containsTechnicalTerms(content) {
        const technicalTerms = ['ai', 'artificial intelligence', 'machine learning', 'deep learning', 'neural', 'algorithm', 'transformer', 'nlp', 'computer vision', 'tensorflow', 'pytorch'];
        return technicalTerms.some(term => content.toLowerCase().includes(term));
    }

    containsResearchTerms(content) {
        const researchTerms = ['research', 'study', 'paper', 'university', 'phd', 'professor', 'scientific', 'journal', 'publication'];
        return researchTerms.some(term => content.toLowerCase().includes(term));
    }

    analyzeEngagement(post, action) {
        // Simulate real-time AI analysis
        const analysis = {
            type: action,
            impact: this.calculateImpact(action),
            sentiment: this.analyzeSentiment(post.content),
            virality: this.predictVirality(post)
        };
        
        console.log('AI Analysis:', analysis);
    }

    calculateImpact(action) {
        const impacts = {
            like: 1,
            comment: 3,
            share: 5
        };
        return impacts[action] || 1;
    }

    predictVirality(post) {
        let score = 0.1;
        
        // Recent posts get higher virality scores
        const hoursAgo = (Date.now() - post.timestamp.getTime()) / (1000 * 60 * 60);
        if (hoursAgo < 1) score += 0.5;
        
        // High engagement increases virality
        if (post.likes > 100) score += 0.3;
        
        return Math.min(1, score);
    }

    // Generate AI Insights
    generateAIInsights() {
        return {
            engagementScore: Math.floor(Math.random() * 20) + 80, // 80-100%
            trendingTopics: [
                { tag: '#MachineLearning', count: 1200 },
                { tag: '#DeepLearning', count: 847 },
                { tag: '#AITransparency', count: 623 },
                { tag: '#EthicalAI', count: 456 }
            ],
            suggestions: [
                'Join the "Future of AI Ethics" discussion group',
                'Connect with Dr. Sarah Kim who shares your research interests',
                'Your post about transformer architectures is gaining traction'
            ]
        };
    }

    // Update real-time features
    initializeRealtimeFeatures() {
        // Simulate real-time engagement updates
        setInterval(() => {
            this.updateEngagementMetrics();
        }, 30000); // Every 30 seconds
        
        // Update time stamps
        setInterval(() => {
            this.updateTimestamps();
        }, 60000); // Every minute
    }

    updateEngagementMetrics() {
        // Simulate dynamic engagement score changes
        const currentScore = parseInt(document.querySelector('.metric-value')?.textContent) || 82;
        const newScore = Math.max(75, Math.min(95, currentScore + (Math.random() - 0.5) * 4));
        
        const metricValue = document.querySelector('.metric-value');
        if (metricValue) {
            metricValue.textContent = Math.round(newScore) + '%';
        }
    }

    updateTimestamps() {
        const timeElements = document.querySelectorAll('.post-time');
        timeElements.forEach(element => {
            const postIndex = Array.from(timeElements).indexOf(element);
            if (this.posts[postIndex]) {
                element.textContent = this.formatTimeAgo(this.posts[postIndex].timestamp);
            }
        });
    }

    formatTimeAgo(timestamp) {
        const now = new Date();
        const diff = now - timestamp;
        const hours = Math.floor(diff / (1000 * 60 * 60));
        const minutes = Math.floor(diff / (1000 * 60));
        
        if (hours > 0) {
            return `${hours} hour${hours > 1 ? 's' : ''} ago`;
        } else {
            return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
        }
    }

    // Start AI analysis simulation
    startAIAnalysis() {
        setInterval(() => {
            this.runPeriodicAIAnalysis();
        }, 120000); // Every 2 minutes
    }

    runPeriodicAIAnalysis() {
        // Simulate AI discovering new trending topics
        if (Math.random() > 0.7) {
            this.discoverNewTrend();
        }
        
        // Simulate AI suggestions
        if (Math.random() > 0.8) {
            this.generatePersonalizedSuggestion();
        }
    }

    discoverNewTrend() {
        const newTrends = ['#QuantumAI', '#FederatedLearning', '#AIEducation', '#SustainableAI'];
        const randomTrend = newTrends[Math.floor(Math.random() * newTrends.length)];
        
        this.showNotification(`AI discovered trending topic: ${randomTrend}`, 'info');
        
        // Update trending list (this would typically update the DOM)
        console.log('New trend discovered:', randomTrend);
    }

    generatePersonalizedSuggestion() {
        const suggestions = [
            'Consider sharing your thoughts on the latest AI conference you attended',
            'Your expertise in machine learning could help answer a question in the research group',
            'AI noticed you haven\'t posted about your recent project - would you like to share?'
        ];
        
        const randomSuggestion = suggestions[Math.floor(Math.random() * suggestions.length)];
        this.showNotification(randomSuggestion, 'info');
    }

    // Update search index
    updateSearchIndex(post) {
        this.searchIndex.push({
            id: post.id,
            author: post.author,
            content: post.content,
            tags: post.aiTags.map(tag => tag.label)
        });
    }

    // Update user statistics
    updateUserStats() {
        // This would typically fetch real data from an API
        setInterval(() => {
            const engagementElement = document.querySelector('.stat-number:last-child');
            if (engagementElement) {
                const current = parseInt(engagementElement.textContent);
                const newValue = Math.max(800, Math.min(900, current + (Math.random() - 0.5) * 10));
                engagementElement.textContent = Math.round(newValue);
            }
        }, 45000); // Every 45 seconds
    }

    // Notification system
    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: var(--neutral-0);
            border: 1px solid var(--neutral-300);
            border-radius: var(--radius-standard);
            padding: var(--space-md) var(--space-lg);
            box-shadow: var(--shadow-hover);
            z-index: 1000;
            max-width: 300px;
            transform: translateX(100%);
            transition: transform 0.3s ease;
        `;
        
        if (type === 'success') {
            notification.style.borderLeft = '4px solid var(--success)';
        } else if (type === 'error') {
            notification.style.borderLeft = '4px solid var(--error)';
        } else {
            notification.style.borderLeft = '4px solid var(--primary-500)';
        }
        
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        // Animate in
        setTimeout(() => {
            notification.style.transform = 'translateX(0)';
        }, 100);
        
        // Remove after delay
        setTimeout(() => {
            notification.style.transform = 'translateX(100%)';
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 4000);
    }

    // Show comment suggestions
    showCommentSuggestions(suggestions) {
        this.showNotification(`AI suggests: "${suggestions[0]}"`, 'info');
    }

    // Search index initialization
    initializeSearchIndex() {
        this.posts.forEach(post => {
            this.updateSearchIndex(post);
        });
    }
}

// Initialize the AI Connect platform when the page loads
document.addEventListener('DOMContentLoaded', () => {
    window.aiConnect = new AIConnect();
    
    // Add some initial notifications to demonstrate AI features
    setTimeout(() => {
        window.aiConnect.showNotification('Welcome to AI Connect! AI is now analyzing your feed.', 'success');
    }, 1000);
    
    setTimeout(() => {
        window.aiConnect.showNotification('AI has discovered 3 trending topics in your network.', 'info');
    }, 3000);
});

// Add some CSS for the notifications
const notificationStyles = document.createElement('style');
notificationStyles.textContent = `
    .notification {
        font-family: var(--font-family);
        font-size: 14px;
        line-height: 1.4;
    }
    
    @media (max-width: 768px) {
        .notification {
            right: var(--space-md);
            left: var(--space-md);
            max-width: none;
        }
    }
`;
document.head.appendChild(notificationStyles);